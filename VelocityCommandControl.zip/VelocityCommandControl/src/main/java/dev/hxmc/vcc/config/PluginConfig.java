package dev.hxmc.vcc.config;

import dev.hxmc.vcc.tab.TabPattern;
import dev.hxmc.vcc.tab.TabPatternParser;
import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * Immutable snapshot of the plugin configuration.
 * <p>
 * Re-parse by calling {@link #load(Path, Logger)} and replacing the reference.
 * All fields are read-only after construction — no synchronization needed at read time.
 */
public final class PluginConfig {

    // ── Feature flags ─────────────────────────────────────────────────────────
    public final boolean ignoreCase;
    public final boolean hideCommandFromClient;
    public final boolean blockTabComplete;
    public final boolean blockCommandExecute;
    public final boolean logBlockedCommand;
    public final String logFormat;

    // ── Message map ───────────────────────────────────────────────────────────
    /** key → formatted message string (& codes already stored as-is) */
    public final Map<String, String> messages;

    // ── Blacklist ─────────────────────────────────────────────────────────────
    /** lower-cased (or exact) command → message key */
    public final Map<String, String> blacklistCommands;

    // ── Tab-complete patterns ─────────────────────────────────────────────────
    /** command name → TabPattern (key already normalised for ignoreCase) */
    public final Map<String, TabPattern> tabPatterns;

    // ─────────────────────────────────────────────────────────────────────────

    private PluginConfig(
            boolean ignoreCase,
            boolean hideCommandFromClient,
            boolean blockTabComplete,
            boolean blockCommandExecute,
            boolean logBlockedCommand,
            String logFormat,
            Map<String, String> messages,
            Map<String, String> blacklistCommands,
            Map<String, TabPattern> tabPatterns
    ) {
        this.ignoreCase = ignoreCase;
        this.hideCommandFromClient = hideCommandFromClient;
        this.blockTabComplete = blockTabComplete;
        this.blockCommandExecute = blockCommandExecute;
        this.logBlockedCommand = logBlockedCommand;
        this.logFormat = logFormat;
        this.messages = Collections.unmodifiableMap(messages);
        this.blacklistCommands = Collections.unmodifiableMap(blacklistCommands);
        this.tabPatterns = Collections.unmodifiableMap(tabPatterns);
    }

    /** Resolve message text for the given key, or a fallback if the key is missing. */
    public String getMessage(String key) {
        return messages.getOrDefault(key, "&cUnknown message key: " + key);
    }

    /** True when this command is blacklisted (already normalised for ignoreCase). */
    public boolean isBlacklisted(String normalisedCommand) {
        return blacklistCommands.containsKey(normalisedCommand);
    }

    /** Normalise a raw command name according to the ignoreCase setting. */
    public String normalise(String command) {
        return ignoreCase ? command.toLowerCase() : command;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Loading
    // ─────────────────────────────────────────────────────────────────────────

    public static PluginConfig load(Path dataFolder, Logger logger) {
        Path configFile = dataFolder.resolve("config.yml");

        // Copy default config if absent
        if (!Files.exists(configFile)) {
            try {
                Files.createDirectories(dataFolder);
                try (InputStream in = PluginConfig.class.getResourceAsStream("/config.yml")) {
                    if (in != null) {
                        Files.copy(in, configFile, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            } catch (IOException e) {
                logger.severe("Could not save default config.yml: " + e.getMessage());
            }
        }

        Map<String, Object> root;
        try (Reader reader = Files.newBufferedReader(configFile)) {
            root = new Yaml().load(reader);
        } catch (IOException e) {
            logger.severe("Failed to read config.yml: " + e.getMessage());
            root = Collections.emptyMap();
        }
        if (root == null) root = Collections.emptyMap();

        // ── Feature flags ──────────────────────────────────────────────────
        boolean ignoreCase         = getBool(root, "ignore-case", true);
        boolean hideCmd            = getBool(root, "hide-command-from-client", true);
        boolean blockTab           = getBool(root, "block-tab-complete", true);
        boolean blockExec          = getBool(root, "block-command-execute", true);
        boolean logBlocked         = getBool(root, "log-blocked-command", true);
        String  logFormat          = getString(root, "log-format",
                "[VelocityCommandControl] %player% attempted to execute %command% on %server%");

        // ── Messages ───────────────────────────────────────────────────────
        Map<String, String> messages = new LinkedHashMap<>();
        Object msgObj = root.get("blacklist-cmd-message");
        if (msgObj instanceof Map<?, ?> msgMap) {
            for (Map.Entry<?, ?> entry : msgMap.entrySet()) {
                messages.put(String.valueOf(entry.getKey()), String.valueOf(entry.getValue()));
            }
        }

        // ── Blacklist ──────────────────────────────────────────────────────
        Map<String, String> blacklist = new LinkedHashMap<>();
        Object blObj = root.get("blacklist-cmd");
        if (blObj instanceof Map<?, ?> blMap) {
            for (Map.Entry<?, ?> entry : blMap.entrySet()) {
                String cmd = ignoreCase
                        ? String.valueOf(entry.getKey()).toLowerCase()
                        : String.valueOf(entry.getKey());
                String msgKey = "not-found";
                if (entry.getValue() instanceof Map<?, ?> cmdCfg) {
                    Object mk = cmdCfg.get("message");
                    if (mk != null) msgKey = String.valueOf(mk);
                }
                blacklist.put(cmd, msgKey);
            }
        }

        // ── Tab patterns ───────────────────────────────────────────────────
        Map<String, TabPattern> tabPatterns = new LinkedHashMap<>();
        Object tabObj = root.get("tab-complete-player-cmd");
        if (tabObj instanceof List<?> tabList) {
            for (Object item : tabList) {
                if (item == null) continue;
                TabPattern pattern = TabPatternParser.parse(String.valueOf(item), ignoreCase);
                if (pattern != null) {
                    tabPatterns.put(pattern.getCommand(), pattern);
                }
            }
        }

        logger.info("Loaded " + blacklist.size() + " blacklisted command(s), "
                + tabPatterns.size() + " tab-complete pattern(s), "
                + messages.size() + " message(s).");

        return new PluginConfig(
                ignoreCase, hideCmd, blockTab, blockExec,
                logBlocked, logFormat,
                messages, blacklist, tabPatterns
        );
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private static boolean getBool(Map<String, Object> map, String key, boolean def) {
        Object v = map.get(key);
        return v instanceof Boolean b ? b : def;
    }

    private static String getString(Map<String, Object> map, String key, String def) {
        Object v = map.get(key);
        return v != null ? String.valueOf(v) : def;
    }
}
