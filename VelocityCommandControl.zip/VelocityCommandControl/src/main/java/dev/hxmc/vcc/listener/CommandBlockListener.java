package dev.hxmc.vcc.listener;

import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.command.PlayerAvailableCommandsEvent;
import com.velocitypowered.api.event.command.TabCompleteEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import dev.hxmc.vcc.config.PluginConfig;
import dev.hxmc.vcc.util.ColorUtil;

import java.util.logging.Logger;

/**
 * Listens to command-related events and enforces the blacklist.
 */
public final class CommandBlockListener {

    private final Logger logger;
    private volatile PluginConfig config;

    public CommandBlockListener(Logger logger, PluginConfig config) {
        this.logger = logger;
        this.config = config;
    }

    public void setConfig(PluginConfig config) {
        this.config = config;
    }

    // ── Block command execution ───────────────────────────────────────────────

    @Subscribe(order = PostOrder.FIRST)
    public void onCommandExecute(CommandExecuteEvent event) {
        PluginConfig cfg = this.config;
        if (!cfg.blockCommandExecute) return;
        if (!(event.getCommandSource() instanceof Player player)) return;

        String rawCmd = event.getCommand();
        // rawCmd does NOT include the leading slash
        String baseCmd = extractBase(rawCmd);
        String normCmd = cfg.normalise(baseCmd);

        if (!cfg.isBlacklisted(normCmd)) return;

        // Block it
        event.setResult(CommandExecuteEvent.CommandResult.denied());

        // Send message
        String msgKey = cfg.blacklistCommands.get(normCmd);
        String msgText = cfg.getMessage(msgKey);
        player.sendMessage(ColorUtil.translate(msgText));

        // Log
        if (cfg.logBlockedCommand) {
            String serverName = player.getCurrentServer()
                    .map(ServerConnection::getServerInfo)
                    .map(info -> info.getName())
                    .orElse("unknown");
            String log = cfg.logFormat
                    .replace("%player%", player.getUsername())
                    .replace("%command%", "/" + rawCmd)
                    .replace("%server%", serverName);
            logger.info(log);
        }
    }

    // ── Block tab-completion ──────────────────────────────────────────────────

    @Subscribe(order = PostOrder.FIRST)
    public void onTabComplete(TabCompleteEvent event) {
        PluginConfig cfg = this.config;
        if (!cfg.blockTabComplete) return;

        String partial = event.getPartialMessage();
        if (partial == null || !partial.startsWith("/")) return;

        // Extract base command from partial input
        String withoutSlash = partial.substring(1);
        String baseCmd = extractBase(withoutSlash);
        String normCmd = cfg.normalise(baseCmd);

        if (cfg.isBlacklisted(normCmd)) {
            event.getSuggestions().clear();
        }
    }

    // ── Hide from command tree ────────────────────────────────────────────────

    @Subscribe(order = PostOrder.LAST)
    public void onAvailableCommands(PlayerAvailableCommandsEvent event) {
        PluginConfig cfg = this.config;
        if (!cfg.hideCommandFromClient) return;

        // Remove all blacklisted root nodes from the command tree
        cfg.blacklistCommands.keySet().forEach(cmd -> {
            // The command name stored in blacklist is already normalised;
            // we remove both original-case and lower-case entries just in case.
            event.getRootNode().getChildren().removeIf(node ->
                    node.getName() != null &&
                    cfg.normalise(node.getName()).equals(cmd)
            );
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Extract the first token (base command) from a raw command string. */
    private static String extractBase(String raw) {
        int space = raw.indexOf(' ');
        return space == -1 ? raw : raw.substring(0, space);
    }
}
