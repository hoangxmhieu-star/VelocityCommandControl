package dev.hxmc.vcc.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/**
 * Utility for converting {@code &}-prefixed color-code strings to Adventure {@link Component}.
 */
public final class ColorUtil {

    private static final LegacyComponentSerializer SERIALIZER =
            LegacyComponentSerializer.legacyAmpersand();

    private ColorUtil() {}

    /** Translate {@code &a&lHello} → colored Adventure component. */
    public static Component translate(String raw) {
        if (raw == null || raw.isEmpty()) return Component.empty();
        return SERIALIZER.deserialize(raw);
    }
}
