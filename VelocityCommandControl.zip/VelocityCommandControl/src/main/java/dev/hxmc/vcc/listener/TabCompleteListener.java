package dev.hxmc.vcc.listener;

import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.TabCompleteEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import dev.hxmc.vcc.config.PluginConfig;
import dev.hxmc.vcc.tab.TabPattern;

import java.util.ArrayList;
import java.util.List;

/**
 * Provides custom tab-completion based on configured patterns.
 * <p>
 * This runs AFTER {@link CommandBlockListener} (PostOrder.NORMAL)
 * so blacklisted commands are already cleared before we inject suggestions.
 */
public final class TabCompleteListener {

    private final ProxyServer proxy;
    private volatile PluginConfig config;

    public TabCompleteListener(ProxyServer proxy, PluginConfig config) {
        this.proxy = proxy;
        this.config = config;
    }

    public void setConfig(PluginConfig config) {
        this.config = config;
    }

    @Subscribe(order = PostOrder.NORMAL)
    public void onTabComplete(TabCompleteEvent event) {
        PluginConfig cfg = this.config;

        String partial = event.getPartialMessage();
        if (partial == null || !partial.startsWith("/")) return;

        String withoutSlash = partial.substring(1);

        // Split on space; preserve trailing space to know if user pressed space after a token
        String[] parts = withoutSlash.split(" ", -1);
        if (parts.length == 0) return;

        String baseCmd = cfg.normalise(parts[0]);

        // No pattern for this command → leave suggestions from backend untouched
        TabPattern pattern = cfg.tabPatterns.get(baseCmd);
        if (pattern == null) return;

        // Argument index being completed (0-based; parts[0] is the command itself)
        // parts.length == 1 means cursor is still on the command word → do nothing
        // parts.length == 2 means first argument being typed
        int argIndex = parts.length - 2; // 0-based index of the argument being filled

        // If the partial message ends with a space, the user finished the previous token
        // and is starting a new one → argIndex should be parts.length - 1
        if (partial.endsWith(" ")) {
            argIndex = parts.length - 1;
        }

        if (argIndex < 0) return;

        TabPattern.Slot slot = pattern.getSlot(argIndex);
        if (slot == null) return;

        // If this slot is BACKEND, let the backend handle it (don't override suggestions)
        if (slot.isBackend()) return;

        // Build suggestion list
        String currentInput = partial.endsWith(" ") ? "" : parts[parts.length - 1];

        List<String> suggestions = buildSuggestions(slot, event.getPlayer(), currentInput);

        // Replace existing suggestions with ours
        event.getSuggestions().clear();
        event.getSuggestions().addAll(suggestions);
    }

    private List<String> buildSuggestions(TabPattern.Slot slot, Player player, String currentInput) {
        String lowerInput = currentInput.toLowerCase();
        List<String> result = new ArrayList<>();

        switch (slot.type()) {
            case PLAYER -> {
                for (Player online : proxy.getAllPlayers()) {
                    String name = online.getUsername();
                    if (name.toLowerCase().startsWith(lowerInput)) {
                        result.add(name);
                    }
                }
            }
            case SERVER -> {
                for (RegisteredServer server : proxy.getAllServers()) {
                    String name = server.getServerInfo().getName();
                    if (name.toLowerCase().startsWith(lowerInput)) {
                        result.add(name);
                    }
                }
            }
            case STATIC -> {
                for (String value : slot.staticValues()) {
                    if (value.toLowerCase().startsWith(lowerInput)) {
                        result.add(value);
                    }
                }
            }
            case BACKEND -> { /* handled by caller */ }
        }

        return result;
    }
}
