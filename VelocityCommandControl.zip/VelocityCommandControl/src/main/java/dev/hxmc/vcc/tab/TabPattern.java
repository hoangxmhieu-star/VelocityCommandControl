package dev.hxmc.vcc.tab;

import java.util.List;

/**
 * Represents a single parsed tab-completion rule.
 * <p>
 * Example input:  "send {tabplayer} {tabserver}"
 * Parsed command: "send"
 * Parsed slots:   [ PLAYER, SERVER ]
 */
public final class TabPattern {

    /** Slot type for each argument position. */
    public enum SlotType {
        PLAYER,
        SERVER,
        STATIC,
        BACKEND  // stop Velocity handling; delegate to backend from this arg onward
    }

    /** A single argument slot with its type and optional static values. */
    public record Slot(SlotType type, List<String> staticValues) {

        /** Convenience: true when this slot delegates to backend. */
        public boolean isBackend() {
            return type == SlotType.BACKEND;
        }
    }

    private final String command;       // exact command name, already lower-cased when ignore-case=true
    private final List<Slot> slots;     // immutable ordered list of argument slots

    public TabPattern(String command, List<Slot> slots) {
        this.command = command;
        this.slots = List.copyOf(slots);
    }

    public String getCommand() {
        return command;
    }

    /** Returns the slot definition at the given 0-based argument index, or null if out of range. */
    public Slot getSlot(int index) {
        if (index < 0 || index >= slots.size()) return null;
        return slots.get(index);
    }

    public int slotCount() {
        return slots.size();
    }
}
