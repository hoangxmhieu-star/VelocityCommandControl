package dev.hxmc.vcc.command;

import com.velocitypowered.api.command.SimpleCommand;
import dev.hxmc.vcc.VelocityCommandControl;
import dev.hxmc.vcc.util.ColorUtil;
import net.kyori.adventure.text.Component;

import java.util.List;

/**
 * /vcc reload — reloads the plugin configuration at runtime.
 *
 * Permission: velocitycommandcontrol.reload
 */
public final class ReloadCommand implements SimpleCommand {

    private final VelocityCommandControl plugin;

    public ReloadCommand(VelocityCommandControl plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(Invocation invocation) {
        String[] args = invocation.arguments();
        if (args.length == 0 || !args[0].equalsIgnoreCase("reload")) {
            invocation.source().sendMessage(ColorUtil.translate("&eUsage: &f/vcc reload"));
            return;
        }

        plugin.reload();
        invocation.source().sendMessage(
                ColorUtil.translate("&a[VCC] &fConfiguration reloaded successfully.")
        );
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return invocation.source().hasPermission("velocitycommandcontrol.reload");
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (invocation.arguments().length <= 1) return List.of("reload");
        return List.of();
    }
}
