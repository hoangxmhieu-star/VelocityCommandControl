package dev.hxmc.vcc.tab;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses tab-completion rule strings from config into {@link TabPattern} objects.
 * <p>
 * This runs only once at startup / reload — never during live tab-complete requests.
 */
public final class TabPatternParser {

    private static final Pattern TABCMD_PATTERN = Pattern.compile(
            "^\\{tabcmd:(.+)}$", Pattern.CASE_INSENSITIVE
    );

    private TabPatternParser() {}

    /**
     * Parse a raw config line such as {@code "send {tabplayer} {tabserver}"}.
     *
     * @param raw         the raw config string
     * @param ignoreCase  whether to lower-case the command name
     * @return parsed {@link TabPattern}, or {@code null} if the line is blank/invalid
     */
    public static TabPattern parse(String raw, boolean ignoreCase) {
        if (raw == null || raw.isBlank()) return null;

        String[] tokens = raw.trim().split("\\s+");
        if (tokens.length == 0) return null;

        String command = ignoreCase ? tokens[0].toLowerCase() : tokens[0];

        List<TabPattern.Slot> slots = new ArrayList<>();

        for (int i = 1; i < tokens.length; i++) {
            String token = tokens[i];
            TabPattern.Slot slot = parseSlot(token);
            if (slot == null) {
                // Unknown placeholder — skip gracefully
                continue;
            }
            slots.add(slot);

            // If this slot is BACKEND, stop processing further tokens
            if (slot.isBackend()) break;
        }

        return new TabPattern(command, slots);
    }

    private static TabPattern.Slot parseSlot(String token) {
        return switch (token.toLowerCase()) {
            case "{tabplayer}" -> new TabPattern.Slot(TabPattern.SlotType.PLAYER, List.of());
            case "{tabserver}" -> new TabPattern.Slot(TabPattern.SlotType.SERVER, List.of());
            case "{tabbackend}" -> new TabPattern.Slot(TabPattern.SlotType.BACKEND, List.of());
            default -> {
                Matcher m = TABCMD_PATTERN.matcher(token);
                if (m.matches()) {
                    List<String> values = Arrays.stream(m.group(1).split(","))
                            .map(String::trim)
                            .filter(s -> !s.isEmpty())
                            .toList();
                    yield new TabPattern.Slot(TabPattern.SlotType.STATIC, values);
                }
                yield null; // unrecognised token
            }
        };
    }
}
