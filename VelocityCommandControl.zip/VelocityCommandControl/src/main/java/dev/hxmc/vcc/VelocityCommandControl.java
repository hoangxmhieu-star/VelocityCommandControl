package dev.hxmc.vcc;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.ProxyServer;
import dev.hxmc.vcc.command.ReloadCommand;
import dev.hxmc.vcc.config.PluginConfig;
import dev.hxmc.vcc.listener.CommandBlockListener;
import dev.hxmc.vcc.listener.TabCompleteListener;

import java.nio.file.Path;
import java.util.logging.Logger;

@Plugin(
        id = "velocitycommandcontrol",
        name = "VelocityCommandControl",
        version = "1.0.0",
        description = "Network-wide command blocking and tab-completion control",
        authors = {"HXMC"}
)
public final class VelocityCommandControl {

    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDirectory;

    private volatile PluginConfig config;

    // Listener references so we can hot-swap config on reload
    private CommandBlockListener commandBlockListener;
    private TabCompleteListener  tabCompleteListener;

    @Inject
    public VelocityCommandControl(
            ProxyServer proxy,
            Logger logger,
            @DataDirectory Path dataDirectory
    ) {
        this.proxy         = proxy;
        this.logger        = logger;
        this.dataDirectory = dataDirectory;
    }

    // ─────────────────────────────────────────────────────────────────────────

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        // Load config
        config = PluginConfig.load(dataDirectory, logger);

        // Create listeners
        commandBlockListener = new CommandBlockListener(logger, config);
        tabCompleteListener  = new TabCompleteListener(proxy, config);

        // Register listeners
        proxy.getEventManager().register(this, commandBlockListener);
        proxy.getEventManager().register(this, tabCompleteListener);

        // Register /vcc command
        proxy.getCommandManager().register(
                proxy.getCommandManager().metaBuilder("vcc").build(),
                new ReloadCommand(this)
        );

        logger.info("VelocityCommandControl enabled.");
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        logger.info("VelocityCommandControl disabled.");
    }

    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Hot-reload configuration without restarting Velocity.
     * Called by {@link ReloadCommand}.
     */
    public void reload() {
        PluginConfig newConfig = PluginConfig.load(dataDirectory, logger);
        this.config = newConfig;

        // Push new config to listeners atomically (volatile write + field read)
        commandBlockListener.setConfig(newConfig);
        tabCompleteListener.setConfig(newConfig);

        logger.info("VelocityCommandControl configuration reloaded.");
    }

    // ─────────────────────────────────────────────────────────────────────────

    public PluginConfig getConfig() {
        return config;
    }

    public ProxyServer getProxy() {
        return proxy;
    }

    public Logger getLogger() {
        return logger;
    }
}
